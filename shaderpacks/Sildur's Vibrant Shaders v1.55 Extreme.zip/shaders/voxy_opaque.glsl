layout(location = 0) out vec4 fragData0;
layout(location = 1) out vec4 fragData1;
/*
Sildur's Vibrant Shaders:
https://www.patreon.com/Sildur
https://sildurs-shaders.github.io/
https://twitter.com/SildurFX
https://www.curseforge.com/minecraft/shaders/sildurs-vibrant-shaders

Permissions:
You are not allowed to edit, copy code or share my shaderpack under a different name or claim it as yours.
*/

#define gbuffers_terrain
#include "shaders.settings"


// vertex

//Moving entities IDs
//See block.properties for mapped ids
#define ENTITY_SMALLGRASS   10031.0
#define ENTITY_LOWERGRASS   10175.0		//lower half only in 1.13+
#define ENTITY_UPPERGRASS	10176.0		//upper half only used in 1.13+
#define ENTITY_SMALLENTS    10059.0
#define ENTITY_LEAVES       10018.0
#define ENTITY_VINES        10106.0
#define ENTITY_LILYPAD      10111.0
#define ENTITY_FIRE         10051.0
#define ENTITY_LAVA   		10010.0
#define ENTITY_EMISSIVE		10089.0 	//emissive blocks defined in block.properties
#define ENITIY_SOULFIRE		10091.0
#define METALLIC_BLOCK		10080.0		//defined in block.properties
#define POLISHED_BLOCK		10081.0
#define ENTITY_NON_DIFFUSED 20000.0
#define ENTITY_WAVING_LANTERN 10090.0

// fragment

vec4 encode (vec3 n, vec2 lmap){
    return vec4(n.xy*inversesqrt(n.z*8.0+8.0) + 0.5, lmap);
}

vec3 RGB2YCoCg(vec3 c){
	return vec3( 0.25*c.r+0.5*c.g+0.25*c.b, 0.5*c.r-0.5*c.b +0.5, -0.25*c.r+0.5*c.g-0.25*c.b +0.5);
}

void voxy_emitFragment(VoxyFragmentParameters parameters) {

	// vertex

	float material = 0.02;
	if(parameters.customId == METALLIC_BLOCK) material = 0.4;
	if(parameters.customId  == POLISHED_BLOCK) material = 0.5;

	//Fix colors on emissive blocks, removed lava as it might cause issues with custom optifine color maps.
	if (parameters.customId == ENTITY_FIRE
	|| parameters.customId == ENTITY_EMISSIVE
	|| parameters.customId == ENITIY_SOULFIRE	
	|| parameters.customId == ENTITY_WAVING_LANTERN){
	material = 0.6;
	}

	//if(mc_Entity.x == ENITIY_SOULFIRE || mc_Entity.x == 10090.0) texcoord.z = 0.85; //lightmap change

	//if(parameters.customId == ENTITY_LAVA) material = 0.6;

	//Translucent blocks
	if (parameters.customId == ENTITY_VINES
	|| parameters.customId == ENTITY_SMALLENTS
	|| parameters.customId == ENTITY_NON_DIFFUSED
	|| parameters.customId == ENTITY_LILYPAD
	|| parameters.customId== ENTITY_LAVA
	|| parameters.customId == ENTITY_LEAVES
	|| parameters.customId == ENTITY_SMALLGRASS
	|| parameters.customId == ENTITY_UPPERGRASS
	|| parameters.customId == ENTITY_LOWERGRASS){
	material = 0.7;
	}

	// fragment 
	vec4 albedo = parameters.sampledColour * parameters.tinting;

	vec4 cAlbedo = vec4(RGB2YCoCg(albedo.rgb),albedo.a);

	bool pattern = (mod(gl_FragCoord.x,2.0)==mod(gl_FragCoord.y,2.0));
	cAlbedo.g = (pattern)?cAlbedo.b: cAlbedo.g;
	cAlbedo.b = material;
		
	vec3 normal = vec3(0.0);

	switch (uint(parameters.face) >> 1u) {
		case 0u:
		normal.xyz = vxModelView[1].xyz;
		break;
		case 1u:
		normal.xyz  = vxModelView[2].xyz;
		break;
		case 2u:
		normal.xyz  = vxModelView[0].xyz;
		break;
	}
	if ((parameters.face & 1) == 0) {
		normal.xyz  = -normal.xyz ;
	}

    fragData0 = cAlbedo;
    fragData1 = encode(normal, parameters.lightMap.xy); 
}